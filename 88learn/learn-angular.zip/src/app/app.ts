import {Component} from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    Welcome to Angular!
  `,
})
export class App {}
