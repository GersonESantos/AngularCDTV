import {Component} from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    Hello
  `,
})
export class App {}
